package com.gear.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dto.Trainee;
import com.gear.bean.Gear;
import com.gear.exception.GearException;
import com.gear.service.IGearService;

@Controller
public class GearController {

	@Autowired
	private IGearService gearService;
	
	/*public IGearService getGearService() {
		return gearService;
	}

	public void setGearService(IGearService gearService) {
		this.gearService = gearService;
	}*/

	/*@RequestMapping("show")
	public String showHomePage()
	{
		return "index";
	}*/
	@RequestMapping(value="search",method=RequestMethod.GET)
	public ModelAndView search(@RequestParam("queryId") int id)
	{
		
		Gear myAllData1=gearService.view(id);
		return new ModelAndView("retrievebyId", "temp", myAllData1);
	}
	@RequestMapping("search")
	public ModelAndView search(@RequestParam("queryId") int queryId){
		ModelAndView model = new ModelAndView();
		Gear bean1=new Gear();
		
		try {
			bean1=gearService.view(queryId);
			model.addObject("gear",bean1);
			//model.addObject("message", "Deleted");
			model.setViewName("viewsucc");
			
		} catch (GearException e) {
			model.setViewName("error");
			model.addObject("message","Unable to view in controller"+e.getMessage());
		}
		
		return model;
	}
	
	@RequestMapping("updatedsuccessfully")
	public String success(){
		return "updatedsuccessfully";
	}
	
	@RequestMapping("update")
	public ModelAndView update(@ModelAttribute("gear") Gear gear){

		ModelAndView model=new ModelAndView();
		
		
		try {
			boolean isUpdated=gearService.update(gear);
			model.setViewName("updatedsuccessfully");
			model.addObject("trainee", isUpdated);
		} catch (GearException e) {
			model.setViewName("error");
			model.addObject("message","unable to update in dao layer"+e.getMessage());
		}
		return model;
		
	}
	
}
