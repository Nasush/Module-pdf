package com.gear.service;

import com.gear.bean.Gear;
import com.gear.exception.GearException;

public interface IGearService {
	public Gear view(int queryId)throws GearException;
	
	public boolean update(Gear gear)throws GearException; 
}
