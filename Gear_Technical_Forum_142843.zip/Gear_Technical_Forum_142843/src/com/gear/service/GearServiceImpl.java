package com.gear.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gear.bean.Gear;
import com.gear.dao.IGearDao;
import com.gear.exception.GearException;

@Service("gearservice")
@Transactional
public class GearServiceImpl implements IGearService 
{
	
	@Autowired
	IGearDao gearDao;

	@Override
	public Gear view(int queryId) throws GearException 
	{
		return gearDao.view(queryId);
	}



	@Override
	public boolean update(Gear gear) throws GearException 
	{
		
		return gearDao.update(gear);
	}

}
